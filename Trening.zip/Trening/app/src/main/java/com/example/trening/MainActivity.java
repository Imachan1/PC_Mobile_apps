package com.example.trening;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    EditText editTextName;
    RadioGroup radioGroup;
    SeekBar seekBar;
    TextView textSeries;
    CheckBox checkBoxFav;
    Button buttonSave;
    ImageView imageView;
    TextView textResult;

    int series = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextName = findViewById(R.id.editTextName);
        radioGroup = findViewById(R.id.radioGroup);
        seekBar = findViewById(R.id.seekBar);
        textSeries = findViewById(R.id.textSeries);
        checkBoxFav = findViewById(R.id.checkBoxFav);
        buttonSave = findViewById(R.id.buttonSave);
        imageView = findViewById(R.id.imageView);
        textResult = findViewById(R.id.textResult);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                series = progress + 1;
                textSeries.setText("Serie: " + series);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = editTextName.getText().toString();

                if(name.isEmpty()){
                    textResult.setText("Błąd: wpisz nazwę ćwiczenia");
                    return;
                }

                if(radioGroup.getCheckedRadioButtonId() == -1){
                    textResult.setText("Błąd: wybierz grupę mięśniową");
                    return;
                }

                String group = "";
                int selectedId = radioGroup.getCheckedRadioButtonId();

                if(selectedId == R.id.radioNogi){
                    group = "Nogi";
                } else if(selectedId == R.id.radioPlecy){
                    group = "Plecy";
                } else if(selectedId == R.id.radioKlatka){
                    group = "Klatka";
                }

                if(series <= 4){
                    imageView.setImageResource(R.drawable.minus);
                } else {
                    imageView.setImageResource(R.drawable.plus);
                }

                String result = "Ćwiczenie: " + name +
                        "\nGrupa: " + group +
                        "\nSerie: " + series;

                if(checkBoxFav.isChecked()){
                    result += "\n(Dodano do ulubionych)";
                }

                textResult.setText(result);
            }
        });
    }
}